#!/usr/bin/env python3

# Note: This script runs theHarvester

from theHarvester import __main__
__main__.entry_point()
